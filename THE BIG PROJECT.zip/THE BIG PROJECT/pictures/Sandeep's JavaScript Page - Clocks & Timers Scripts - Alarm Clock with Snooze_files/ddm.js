<!-- 
function gotopage() {
  if (document.dpdown.choice.selectedIndex==0) return;
  if (document.dpdown.choice.selectedIndex==1) { location.href="../../home/index.html"; }
  if (document.dpdown.choice.selectedIndex==2) { location.href="../../home/fitness/index.html"; }
  if (document.dpdown.choice.selectedIndex==3) { location.href="../../home/quotes/index.html"; }
  if (document.dpdown.choice.selectedIndex==4) { location.href="../../home/album/index.html"; }
  if (document.dpdown.choice.selectedIndex==5) { location.href="../../home/files/site_map.html"; }
  if (document.dpdown.choice.selectedIndex==6) { location.href="../files/contact.html"; }
}
// -->